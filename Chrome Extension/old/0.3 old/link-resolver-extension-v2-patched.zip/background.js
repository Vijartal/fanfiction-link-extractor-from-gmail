// background.js (patched: Drive view transform + header then query-token fallback)
// Default configuration. Options page overrides via chrome.storage.local.CONFIG
const DEFAULT_CONFIG = {
  FILE_FETCH_URL: '', // set in Options
  POST_BACK_URL: '',  // set in Options
  INITIAL_DELAY_MIN: 5
};

const DEFAULT_STATE = {
  status: 'idle', // idle, fetching, opened, waiting, polling, completed, aborted, error
  message: 'Ready.',
  total: 0,
  completed: 0,
  linksFound: [],
  lastErrorSample: ''
};

let state = Object.assign({}, DEFAULT_STATE);
let targetWinId = null;
let progressWinId = null;
let abortFlag = false;

// Utility: persist and broadcast state
function setState(updates) {
  state = Object.assign({}, state, updates);
  chrome.storage.local.set({ EXT_STATUS: state }, () => {});
  chrome.runtime.sendMessage({ type: 'STATUS', state });
  readDebugFlag().then(debug => {
    if (debug) console.log('[LR] STATE:', state);
  });
}

// Read config & token & debug flag
function readConfig() {
  return new Promise(resolve => {
    chrome.storage.local.get(['CONFIG','AUTH_TOKEN','DEBUG'], res => {
      resolve({
        cfg: Object.assign({}, DEFAULT_CONFIG, res.CONFIG || {}),
        token: res.AUTH_TOKEN || '',
        debug: !!res.DEBUG
      });
    });
  });
}

function readDebugFlag() {
  return new Promise(resolve => {
    chrome.storage.local.get('DEBUG', res => resolve(!!res.DEBUG));
  });
}

// Resilient link regex: account for forum / forums and optional www
const RUNTIME_LINK_REGEX = /https?:\/\/(?:www\.)?(?:forums?\.(?:sufficientvelocity|spacebattles)\.com|forum\.questionablequesting\.com)\/posts\/(\d{5,12})(?:\/[^\s]*)?/ig;

// Message listener (Start, Abort, GET_STATUS)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) {
    sendResponse({ ok: false });
    return;
  }
  if (msg.type === 'START') {
    startProcess();
    sendResponse({ ok: true });
  } else if (msg.type === 'ABORT') {
    abortFlag = true;
    setState({ status: 'aborting', message: 'Abort requested' });
    sendResponse({ ok: true });
  } else if (msg.type === 'GET_STATUS') {
    chrome.storage.local.get('EXT_STATUS', data => {
      sendResponse({ status: data.EXT_STATUS || state });
    });
    return true; // asynchronous response
  } else {
    sendResponse({ ok: false });
  }
});

// ---------- startProcess (patched) ----------
async function startProcess() {
  abortFlag = false;

  // read config, token & debug flag
  const { cfg, token, debug } = await readConfig();

  if (!cfg.FILE_FETCH_URL) {
    setState({ status: 'error', message: 'No FILE_FETCH_URL set in Options' });
    return;
  }

  setState({ status: 'fetching', message: 'Fetching link file...', total: 0, completed: 0, linksFound: [], lastErrorSample: '' });

  // Helper: convert Drive "view" URLs to raw download URLs
  function transformDriveViewUrl(url) {
    if (!url || typeof url !== 'string') return url;
    if (/drive\.google\.com\/uc\?export=download/i.test(url)) return url;
    const m1 = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    if (m1 && m1[1]) return `https://drive.google.com/uc?export=download&id=${m1[1]}`;
    const m2 = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
    if (m2 && m2[1]) return `https://drive.google.com/uc?export=download&id=${m2[1]}`;
    return url;
  }

  // --- FETCH BLOCK with header then query-param fallback ---
  let text;
  try {
    const fetchUrl = transformDriveViewUrl(cfg.FILE_FETCH_URL);
    if (debug) console.log('[LR] Fetch URL used:', fetchUrl);

    // build headers if token present
    const headers = {};
    if (token) headers['Authorization'] = 'Bearer ' + token;

    // primary attempt (header)
    let resp = await fetch(fetchUrl, {
      method: 'GET',
      cache: 'no-store',
      headers,
      credentials: 'omit'
    });

    // read text for decision-making
    text = await resp.text();

    // If the server says "Unauthorized" or returned 401, try fallback
    const lower = (text || '').trim().toLowerCase();
    if (resp.status === 401 || lower === 'unauthorized') {
      if (debug) console.warn('[LR] Primary fetch unauthorized. Trying fallback with token query param.');

      // retry using ?token=... to handle servers that don't read Authorization header
      if (token) {
        const sep = fetchUrl.includes('?') ? '&' : '?';
        const fallbackUrl = fetchUrl + sep + 'token=' + encodeURIComponent(token);
        if (debug) console.log('[LR] Fallback URL:', fallbackUrl);

        const resp2 = await fetch(fallbackUrl, { method: 'GET', cache: 'no-store', credentials: 'omit' });
        text = await resp2.text();
        if (!resp2.ok) {
          setState({ status: 'error', message: `Fetch failed (fallback): ${resp2.status} ${resp2.statusText}` });
          if (debug) console.error('[LR] Fallback fetch not ok:', resp2.status, resp2.statusText, 'body:', text);
          return;
        }
        // fallback returned OK — continue with new text
      } else {
        // no token to try as query param
        setState({ status: 'error', message: 'Unauthorized (no token present in extension options)' });
        return;
      }
    } else {
      // primary response OK; check resp.ok
      if (!resp.ok) {
        setState({ status: 'error', message: `Fetch failed: ${resp.status} ${resp.statusText}` });
        if (debug) console.error('[LR] fetch response not ok:', resp.status, resp.statusText, 'body:', text);
        return;
      }
    }
  } catch (err) {
    setState({ status: 'error', message: 'Fetch error: ' + err.message });
    if (debug) console.error('[LR] fetch error:', err);
    return;
  }
  // --- END FETCH BLOCK ---

  // Quick content check: if it looks like HTML, fail with sample
  const sample = (typeof text === 'string') ? text.slice(0, 2000) : '';
  if (/<!doctype html|<html|<head|<body/i.test(sample)) {
    setState({
      status: 'error',
      message: 'Fetched content appears to be HTML (likely a login page). Make the file public or use a public endpoint.',
      lastErrorSample: sample
    });
    if (debug) console.error('[LR] HTML-like content fetched:', sample);
    return;
  }

  // Extract links using runtime regex
  const found = [];
  let mm;
  while ((mm = RUNTIME_LINK_REGEX.exec(text)) !== null) {
    found.push(mm[0]);
  }

  if (found.length === 0) {
    setState({ status: 'error', message: 'No SV/SB/QQ links found in file', lastErrorSample: sample });
    if (debug) console.warn('[LR] No matches; file sample:', sample.slice(0, 800));
    return;
  }

  setState({
    status: 'opened',
    message: `Found ${found.length} links. Opening popup...`,
    linksFound: found,
    total: found.length,
    completed: 0
  });

  // Open target window
  try {
    const targetWin = await chrome.windows.create({ url: found, type: 'popup' });
    targetWinId = targetWin.id;
  } catch (err) {
    setState({ status: 'error', message: 'Failed to open target window: ' + err.message });
    if (debug) console.error('[LR] open target window error:', err);
    return;
  }

  // Open progress UI (non-fatal)
  try {
    const progWin = await chrome.windows.create({
      url: chrome.runtime.getURL('progress.html'),
      type: 'popup',
      width: 380,
      height: 160
    });
    progressWinId = progWin.id;
  } catch (err) {
    if (debug) console.warn('[LR] Failed to open progress window:', err);
  }

  setState({ status: 'waiting', message: `Waiting ${cfg.INITIAL_DELAY_MIN} minute(s) before polling.` });

  // schedule poll alarm (single alarm)
  chrome.alarms.clear('startPolling');
  chrome.alarms.create('startPolling', { delayInMinutes: Number(cfg.INITIAL_DELAY_MIN) || 5 });
}
// ---------- end startProcess ----------
