
let targetWinId = null;
let linksQueue = [];
let inProgress = new Map();
let resolvedUrls = [];
let intervalId = null;
const requiredChecks = 3;
const maxConcurrentTabs = 3;

// Dummy readConfig for completeness
async function readConfig() {
  return { cfg: {}, token: null, debug: true };
}

async function readDebugFlag() {
  return true;
}

async function setState(obj) {
  console.log("[STATE]", obj);
}

async function finalizeAndPost() {
  console.log("[FINALIZE] Resolved URLs:", resolvedUrls);
}

// Start process with queue of links
async function startProcess(links) {
  const { cfg, token, debug } = await readConfig();
  linksQueue = [...links];
  resolvedUrls = [];
  inProgress.clear();

  intervalId = setInterval(checkTabs, 2000);

  // Open initial batch up to concurrency limit
  for (let i = 0; i < Math.min(maxConcurrentTabs, linksQueue.length); i++) {
    const nextUrl = linksQueue.shift();
    const newWin = await chrome.windows.create({ url: nextUrl, type: "popup" });
    targetWinId = newWin.id;
    await new Promise(r => setTimeout(r, 300));
    const tabsNow = await chrome.tabs.query({ windowId: targetWinId });
    if (tabsNow && tabsNow.length > 0) {
      const newTab = tabsNow[0];
      inProgress.set(newTab.id, { intendedUrl: nextUrl, checks: 0, lastUrl: "" });
    }
  }
}

async function checkTabs() {
  for (const [tabId, rec] of [...inProgress.entries()]) {
    let tab;
    try {
      [tab] = await chrome.tabs.query({ windowId: targetWinId, active: true, status: "complete" });
    } catch (err) {
      continue;
    }
    if (!tab) continue;

    const currUrl = tab.url || "";
    if (currUrl && currUrl !== rec.lastUrl) {
      rec.checks++;
      rec.lastUrl = currUrl;
    }

    if (rec.checks >= requiredChecks) {
      const resolved = currUrl;
      resolvedUrls.push(resolved);
      setState({
        status: "processing",
        message: `Tab resolved: ${resolved}`,
        completed: resolvedUrls.length
      });

      inProgress.delete(tab.id);

      if (linksQueue.length > 0) {
        const nextUrl = linksQueue.shift();
        let windowValid = true;
        try {
          await chrome.windows.get(targetWinId);
        } catch (err) {
          windowValid = false;
        }

        if (!windowValid) {
          try {
            const newWin = await chrome.windows.create({ url: nextUrl, type: "popup" });
            targetWinId = newWin.id;
            await new Promise(r => setTimeout(r, 300));
            const tabsNow = await chrome.tabs.query({ windowId: targetWinId });
            if (tabsNow && tabsNow.length > 0) {
              const newTab = tabsNow[0];
              inProgress.set(newTab.id, { intendedUrl: nextUrl, checks: 0, lastUrl: "" });
            }
          } catch (err) {
            linksQueue.unshift(nextUrl);
          }
        } else {
          try {
            await chrome.tabs.update(tab.id, { url: nextUrl });
            inProgress.set(tab.id, { intendedUrl: nextUrl, checks: 0, lastUrl: "" });
          } catch (err) {
            try {
              const newTab = await chrome.tabs.create({ windowId: targetWinId, url: nextUrl });
              inProgress.set(newTab.id, { intendedUrl: nextUrl, checks: 0, lastUrl: "" });
            } catch (err2) {
              linksQueue.unshift(nextUrl);
            }
            try { await chrome.tabs.remove(tab.id); } catch {}
          }
        }
      } else {
        try { await chrome.tabs.remove(tab.id); } catch {}
      }

      if (linksQueue.length === 0 && inProgress.size === 0) {
        clearInterval(intervalId);
        await finalizeAndPost();
        return;
      }
    }
  }
}

// Expose startProcess for testing
globalThis.startProcess = startProcess;
