// Popup control logic
const statusEl = document.getElementById('status');
const progressEl = document.getElementById('progress');
const messageEl = document.getElementById('message');
document.getElementById('start').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'START' });
});
document.getElementById('abort').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'ABORT' });
});
document.getElementById('options').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});
document.getElementById('refresh').addEventListener('click', () => {
  requestStatus();
});

function updateUI(state) {
  statusEl.textContent = 'Status: ' + (state.status || 'idle');
  progressEl.textContent = 'Resolved: ' + (state.completed || 0) + ' / ' + (state.total || 0);
  messageEl.textContent = state.message || '';
}

function requestStatus() {
  chrome.runtime.sendMessage({ type: 'GET_STATUS' }, res => {
    if (res && res.status) updateUI(res.status);
  });
}

// live updates from background
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'STATUS') {
    updateUI(msg.state || {});
  }
});

// initial load
requestStatus();
