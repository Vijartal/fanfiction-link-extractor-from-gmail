const statusEl = document.getElementById('status');
const progressEl = document.getElementById('progress');
document.getElementById('abort').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'ABORT' });
  statusEl.textContent = 'Abort requested...';
});

// receive status updates
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'STATUS' && msg.state) {
    const s = msg.state;
    statusEl.textContent = (s.message || 'Status:') + ' (' + (s.status || '') + ')';
    progressEl.textContent = 'Resolved: ' + (s.completed || 0) + ' / ' + (s.total || 0);
  }
});

// request current status on load
chrome.runtime.sendMessage({ type: 'GET_STATUS' }, res => {
  if (res && res.status) {
    chrome.runtime.sendMessage({ type: 'STATUS_UPDATE_REQUEST' }); // optional ping
    const s = res.status;
    statusEl.textContent = (s.message || 'Status:') + ' (' + (s.status || '') + ')';
    progressEl.textContent = 'Resolved: ' + (s.completed || 0) + ' / ' + (s.total || 0);
  }
});
