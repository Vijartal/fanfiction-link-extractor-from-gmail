// Background service worker for Link Resolver v2
const DEFAULT_CONFIG = {
  FILE_FETCH_URL: 'https://your_server_or_drive_link/FF%20links%20extracted%20from%20gmail.txt',
  POST_BACK_URL: 'https://script.google.com/macros/s/your-deployment-id/exec',
  INITIAL_DELAY_MIN: 5
};

let state = {
  status: 'idle',         // idle | fetching | opened | waiting | polling | completed | aborted | error
  message: '',
  total: 0,
  completed: 0,
  targetWinId: null,
  progressWinId: null,
  links: []
};

let abortFlag = false;

function setState(updates) {
  Object.assign(state, updates);
  chrome.storage.local.set({ EXT_STATUS: state });
  chrome.runtime.sendMessage({ type: 'STATUS', state });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type) {
    if (msg.type === 'START') {
      startProcess();
      sendResponse({ ok: true });
    } else if (msg.type === 'ABORT') {
      abortFlag = true;
      setState({ status: 'aborting', message: 'Abort requested by user' });
      sendResponse({ ok: true });
    } else if (msg.type === 'GET_STATUS') {
      chrome.storage.local.get('EXT_STATUS', data => {
        sendResponse({ status: data.EXT_STATUS || state });
      });
      return true; // will respond asynchronously
    }
  }
});

// Utility: read config and auth token from storage
function readConfigAndToken() {
  return new Promise(resolve => {
    chrome.storage.local.get(['CONFIG','AUTH_TOKEN'], res => {
      const cfg = Object.assign({}, DEFAULT_CONFIG, res.CONFIG || {});
      const token = res.AUTH_TOKEN || '';
      resolve({ cfg, token });
    });
  });
}

async function startProcess() {
  abortFlag = false;
  setState({ status: 'fetching', message: 'Fetching link file...', total:0, completed:0, links: [] });

  const { cfg } = await readConfigAndToken();
  try {
    const resp = await fetch(cfg.FILE_FETCH_URL);
    if (!resp.ok) throw new Error('Fetch failed: ' + resp.status);
    const text = await resp.text();
    // extract SV / SB / QQ links only
    const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const links = lines
      .map(l => l.split('|').pop().trim())
      .filter(url => /https?:\/\/(?:forums\.(?:sufficientvelocity|spacebattles)\.com\/posts\/\d{6,9}|forum\.questionablequesting\.com\/posts\/\d{6,9})/i.test(url));

    if (!links.length) {
      setState({ status: 'idle', message: 'No SV/SB/QQ links found in file.' });
      return;
    }

    setState({ status: 'opened', message: 'Opening links in popup window...', links, total: links.length, completed: 0 });

    // open target popup with all links
    const targetWin = await chrome.windows.create({ url: links, type: 'popup' });
    state.targetWinId = targetWin.id;

    // open progress UI window
    const progWin = await chrome.windows.create({
      url: chrome.runtime.getURL('progress.html'),
      type: 'popup',
      width: 360,
      height: 160
    });
    state.progressWinId = progWin.id;
    setState({ status: 'waiting', message: `Waiting ${cfg.INITIAL_DELAY_MIN} minute(s) before polling.` });

    // schedule alarm
    chrome.alarms.create('startPolling', { delayInMinutes: Number(cfg.INITIAL_DELAY_MIN) || 5 });
  } catch (err) {
    setState({ status: 'error', message: 'Error fetching/parsing links: ' + err.message });
  }
}

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'startPolling') {
    pollTabs();
  }
});

async function pollTabs() {
  if (abortFlag) {
    setState({ status: 'aborted', message: 'Aborted by user' });
    cleanup();
    return;
  }

  if (!state.targetWinId) {
    setState({ status: 'error', message: 'Target window not found' });
    cleanup();
    return;
  }

  setState({ status: 'polling', message: 'Checking tab load status...' });

  try {
    const tabs = await chrome.tabs.query({ windowId: state.targetWinId });
    const total = tabs.length;
    const completed = tabs.filter(t => t.status === 'complete').length;
    setState({ total, completed });

    if (abortFlag) {
      setState({ status: 'aborted', message: 'Aborted by user' });
      cleanup();
      return;
    }

    if (completed === total) {
      setState({ status: 'completed', message: 'All tabs loaded — resolving URLs...' });
      const resolved = tabs.map(t => t.url);

      // post resolved URLs
      const { cfg, token } = await readConfigAndToken();
      try {
        const headers = { 'Content-Type': 'application/json' };
        if (token && token.length) headers['Authorization'] = 'Bearer ' + token;
        await fetch(cfg.POST_BACK_URL, {
          method: 'POST',
          headers,
          body: JSON.stringify({ resolved })
        });
        setState({ status: 'done', message: `Posted ${resolved.length} resolved URLs.` });
      } catch (postErr) {
        setState({ status: 'error', message: 'Failed to POST resolved URLs: ' + postErr.message });
      }

      cleanup();
    } else {
      // not all complete -> re-check after 1 minute; but also update progress UI
      setState({ status: 'waiting', message: `Only ${completed}/${total} tabs loaded. Re-checking in 60s.` });
      setTimeout(() => { pollTabs(); }, 60_000);
    }
  } catch (err) {
    setState({ status: 'error', message: 'Error polling tabs: ' + err.message });
    cleanup();
  }
}

function cleanup() {
  if (state.targetWinId) {
    chrome.windows.remove(state.targetWinId).catch(()=>{});
  }
  if (state.progressWinId) {
    chrome.windows.remove(state.progressWinId).catch(()=>{});
  }
  chrome.alarms.clearAll();
  state.targetWinId = null;
  state.progressWinId = null;
  state.links = [];
  // keep last status message but set idle after short delay
  setTimeout(() => { setState({ status: 'idle', message: 'Ready.' }); }, 2000);
}
