// Options page logic
const fileUrlEl = document.getElementById('fileUrl');
const postUrlEl = document.getElementById('postUrl');
const delayEl = document.getElementById('delay');
const tokenEl = document.getElementById('token');
const statusEl = document.getElementById('status');

document.getElementById('save').addEventListener('click', () => {
  const cfg = {
    FILE_FETCH_URL: fileUrlEl.value.trim(),
    POST_BACK_URL: postUrlEl.value.trim(),
    INITIAL_DELAY_MIN: Number(delayEl.value) || 5
  };
  const token = tokenEl.value.trim();
  chrome.storage.local.set({ CONFIG: cfg, AUTH_TOKEN: token }, () => {
    statusEl.textContent = 'Saved.';
    setTimeout(()=>statusEl.textContent='',2000);
  });
});

document.getElementById('reset').addEventListener('click', () => {
  chrome.storage.local.remove(['CONFIG','AUTH_TOKEN'], () => {
    loadValues();
    statusEl.textContent = 'Reset to defaults.';
    setTimeout(()=>statusEl.textContent='',2000);
  });
});

function loadValues() {
  chrome.storage.local.get(['CONFIG','AUTH_TOKEN'], res => {
    const cfg = res.CONFIG || {};
    fileUrlEl.value = cfg.FILE_FETCH_URL || '';
    postUrlEl.value = cfg.POST_BACK_URL || '';
    delayEl.value = (cfg.INITIAL_DELAY_MIN !== undefined) ? cfg.INITIAL_DELAY_MIN : 5;
    tokenEl.value = res.AUTH_TOKEN || '';
  });
}

loadValues();
